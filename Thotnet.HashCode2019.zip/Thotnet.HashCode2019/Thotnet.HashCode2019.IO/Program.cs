﻿using System;

namespace Thotnet.HashCode2019.Runner
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello Thots!");
        }
    }
}
